import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import * as Localization from "expo-localization";

const resources = {
  en: {
    translation: {
      welcome: "Welcome to PeerXMarket",
      connectWallet: "Connect Wallet",
    },
  },
  pt: {
    translation: {
      welcome: "Bem-vindo ao PeerXMarket",
      connectWallet: "Conectar Carteira",
    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: Localization.locale.split("-")[0], // Define o idioma com base no dispositivo
  fallbackLng: "en",
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
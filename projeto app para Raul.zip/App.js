import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import WalletConnectProvider, { useWalletConnect } from "@walletconnect/react-native-dapp";
import * as Localization from "expo-localization";
import i18n from "./i18n";
import { NavigationContainer } from "@react-navigation/native";

export default function App() {
  return (
    <WalletConnectProvider
      bridge="https://bridge.walletconnect.org"
      clientMeta={{
        description: "Connect with PeerXMarket",
        url: "https://peerxmarket.com",
        icons: ["https://peerxmarket.com/icon.png"],
        name: "PeerXMarket",
      }}
    >
      <NavigationContainer>
        <MainApp />
      </NavigationContainer>
    </WalletConnectProvider>
  );
}

function MainApp() {
  const [language, setLanguage] = useState("en");
  const [walletAddress, setWalletAddress] = useState("");

  const connector = useWalletConnect();

  useEffect(() => {
    const loadLanguage = async () => {
      const savedLanguage = await AsyncStorage.getItem("appLanguage");
      if (savedLanguage) setLanguage(savedLanguage);
    };
    loadLanguage();
  }, []);

  const handleConnectWallet = () => {
    if (!connector.connected) {
      connector.connect();
    } else {
      setWalletAddress(connector.accounts[0]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>{i18n.t("welcome")}</Text>
      <TouchableOpacity style={styles.button} onPress={handleConnectWallet}>
        <Text style={styles.buttonText}>
          {walletAddress ? `Connected: ${walletAddress}` : i18n.t("connectWallet")}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#007bff",
    padding: 15,
    borderRadius: 5,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
});